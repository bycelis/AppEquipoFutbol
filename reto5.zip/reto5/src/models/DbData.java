package models;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DbData {

    static Connection miconexion = null;
    static String db = "reto5";
    static String host = "localhost";
    static String puerto = "3306";
    static String usuario = "root";
    static String clave = "";

    static String driverConexion = "com.mysql.jdbc.Driver";
    static String url = "jdbc:mysql://" + host + ":" + puerto + "/" + db;

    public static Connection DbData() {
        try {
            Class.forName(driverConexion);
            miconexion = (Connection) DriverManager.getConnection(url, usuario, clave);
            if (!miconexion.isClosed()) {
                System.out.println("se conecto correctamente ala DB");
            }
            return miconexion;
        } catch (ClassNotFoundException | SQLException exepcion) {
            Logger.getLogger(DbData.class.getName()).log(Level.SEVERE, null, exepcion);
            return null;
        }
    }

    public static Connection getConexion() {
        return miconexion;
    }

    public static Connection cerrarBD() {
        try {
            Class.forName(driverConexion);
            miconexion = (Connection) DriverManager.getConnection(url, usuario, clave);
            miconexion.isClosed();
            return miconexion;
        } catch (ClassNotFoundException | SQLException exepcion) {
            Logger.getLogger(DbData.class.getName()).log(Level.SEVERE, null, exepcion);
            return null;
        }
    }
}
