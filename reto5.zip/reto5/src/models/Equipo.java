package models;

public class Equipo extends Municipio {

    int id;
    String nombre;
    String dt;
    int municipio;

    public Equipo() {
    }

    public Equipo(String nombre, String dt, int municipio) {
        this.nombre = nombre;
        this.dt = dt;
        this.municipio = municipio;
    }

    public Equipo(int id, String nombre, String dt, int municipio) {
        this.id = id;
        this.nombre = nombre;
        this.dt = dt;
        this.municipio = municipio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDt() {
        return dt;
    }

    public void setDt(String dt) {
        this.dt = dt;
    }

    public int getMunicipio() {
        return municipio;
    }

    public void setMunicipio(int municipio) {
        this.municipio = municipio;
    }

    @Override
    public String toString() {
        return "" + nombre ;
    }

}
