package models;

public class Jugador {

    int id;
    String nombre;
    int numero;
    int equipoid;
    int posicionid;

    public Jugador() {
    }

    public Jugador(String nombre, int numero, int equipoid, int posicionid) {
        this.nombre = nombre;
        this.numero = numero;
        this.equipoid = equipoid;
        this.posicionid = posicionid;
    }

    public Jugador(int id, String nombre, int numero, int equipoid, int posicionid) {
        this.id = id;
        this.nombre = nombre;
        this.numero = numero;
        this.equipoid = equipoid;
        this.posicionid = posicionid;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getEquipoid() {
        return equipoid;
    }

    public void setEquipoid(int equipoid) {
        this.equipoid = equipoid;
    }

    public int getPosicionid() {
        return posicionid;
    }

    public void setPosicionid(int posicionid) {
        this.posicionid = posicionid;
    }

    @Override
    public String toString() {
        return "Jugador{" + "id=" + id + ", nombre=" + nombre + ", numero=" + numero + ", equipoid=" + equipoid + ", posicionid=" + posicionid + '}';
    }

}
