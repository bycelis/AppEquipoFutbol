package principal;

import controller.TorneoController;
import view.FrmFormulario;

public class Principal {

    public static void main(String[] args) {
        FrmFormulario objFrmCartera = new FrmFormulario();
        objFrmCartera.setLocationRelativeTo(null);
        objFrmCartera.setVisible(true);

    }

}
