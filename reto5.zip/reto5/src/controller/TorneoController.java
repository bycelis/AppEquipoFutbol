package controller;

import com.mysql.jdbc.PreparedStatement;
import java.sql.Connection;
import models.DbData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import static models.DbData.*;
import models.*;

public class TorneoController {

    DbData miConexion = new DbData();
    PreparedStatement stmt = null;

    public ResultSet listar() {
        ResultSet rs = null;
        try {
            String sql = "SELECT jugadores.nombre AS nombre_jugador,jugadores.numero AS numero_jugador,\n"
                    + "municipios.nombre AS municipio,equipos.nombre AS nombre_equipo,\n"
                    + "equipos.dt AS entrenador,posiciones.nombre AS posiciones FROM municipios \n"
                    + "INNER JOIN equipos ON municipios.id = equipos.municipio_id \n"
                    + "INNER JOIN jugadores ON equipos.id = jugadores.equipo_id \n"
                    + "INNER JOIN posiciones ON jugadores.posicion_id = posiciones.id;";
            stmt = (PreparedStatement) miConexion.DbData().prepareStatement(sql);

            rs = stmt.executeQuery();
        } catch (Exception e) {
        }
        miConexion.cerrarBD();
        return rs;
    }

    public List<Municipio> listarMunicipio() {
        List<Municipio> rowsQuery = new ArrayList<Municipio>();
        Connection conex = DbData();
        Municipio objMunicipio;
        try {
            String sql = "SELECT municipios.id AS id, municipios.nombre AS nombre FROM municipios;";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                objMunicipio = new Municipio();
                objMunicipio.setId(resultSet.getInt("id"));
                objMunicipio.setNombre(resultSet.getString("nombre"));

                rowsQuery.add(objMunicipio);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la adquisición de datos");
        }
        miConexion.cerrarBD();
        return rowsQuery;
    }

    public Object insertarMunicipio(Object obj) {
        Connection conex = DbData();
        Municipio objMunicipio = (Municipio) obj;
        try {
            String sql = "INSERT INTO municipios (nombre)VALUES(?);";
            java.sql.PreparedStatement preparedStatement
                    = (java.sql.PreparedStatement) conex.prepareStatement(sql, java.sql.PreparedStatement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, objMunicipio.getNombre());

            preparedStatement.execute();
            ResultSet rs = preparedStatement.getGeneratedKeys();
            while (rs.next()) {
                objMunicipio.setId(rs.getInt(1));
            }
            preparedStatement.close();
            JOptionPane.showMessageDialog(null, "La inserción del árticulo fue exitosa.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al insertar el árticulo");
        }
        miConexion.cerrarBD();
        return objMunicipio;

    }

    public boolean eliminarMunicipio(Object obj) {
        Municipio objMunicipio = (Municipio) obj;
        boolean result = false;
        Connection conex = DbData();
        try {
            String sql = "DELETE FROM municipios WHERE id=?;";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setInt(1, objMunicipio.getId());
            int resultadoEliminacion = preparedStatement.executeUpdate();
            if (resultadoEliminacion == 1) {
                result = true;
            }
            preparedStatement.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar la persona.");
        }
        miConexion.cerrarBD();
        return result;
    }

    public boolean actualizarMunicipio(Object obj) {
        Municipio objMunicipio = (Municipio) obj;
        int result = 0;
        boolean flag = false;
        Connection conex = DbData();
        try {
            String sql = "UPDATE municipios SET nombre=? WHERE id = ?";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setString(1, objMunicipio.getNombre());
            preparedStatement.setInt(2, objMunicipio.getId());
            result = preparedStatement.executeUpdate();

            if (result > 0) {
                flag = true;
            }
            preparedStatement.close();
            JOptionPane.showMessageDialog(null, "La actualización de el Municipio fue exitosa.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en la actualización del Municipio.");
        }
        miConexion.cerrarBD();
        return flag;
    }

    public Object listarUnMunicipio(Object obj) {
        Connection conex = DbData();
        Municipio objMunicipio = (Municipio) obj;
        try {
            String sql = "SELECT * FROM municipios WHERE id=?";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setInt(1, objMunicipio.getId());
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                objMunicipio.setId(resultSet.getInt("id"));
                objMunicipio.setNombre(resultSet.getString("nombre"));
            }
            preparedStatement.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la adquisición de datos");
        }
        miConexion.cerrarBD();
        return objMunicipio;
    }
    
    public List<Object> listarPosiciones() {
        List<Object> rowsQuery = new ArrayList<Object>();
        Connection conex = DbData();
        Posicion objPosiciones;
        try {
            String sql = "SELECT posiciones.id AS id, posiciones.nombre AS nombre FROM posiciones;";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                objPosiciones = new Posicion();
                objPosiciones.setId(resultSet.getInt("id"));
                objPosiciones.setNombre(resultSet.getString("nombre"));

                rowsQuery.add(objPosiciones);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la adquisición de datos");
        }
        miConexion.cerrarBD();
        return rowsQuery;
    }

    public Object insertarPosiciones(Object obj) {
        Connection conex = DbData();
        Posicion objPosiciones = (Posicion) obj;
        try {
            String sql = "INSERT INTO posiciones (nombre)VALUES(?);";
            java.sql.PreparedStatement preparedStatement
                    = (java.sql.PreparedStatement) conex.prepareStatement(sql, java.sql.PreparedStatement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, objPosiciones.getNombre());

            preparedStatement.execute();
            ResultSet rs = preparedStatement.getGeneratedKeys();
            while (rs.next()) {
                objPosiciones.setId(rs.getInt(1));
            }
            preparedStatement.close();
            JOptionPane.showMessageDialog(null, "La inserción del árticulo fue exitosa.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al insertar el árticulo");
        }
        miConexion.cerrarBD();
        return objPosiciones;

    }

    public boolean eliminarPosiciones(Object obj) {
        Posicion objPosiciones = (Posicion) obj;
        boolean result = false;
        Connection conex = DbData();
        try {
            String sql = "DELETE FROM posiciones WHERE id=?;";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setInt(1, objPosiciones.getId());
            int resultadoEliminacion = preparedStatement.executeUpdate();
            if (resultadoEliminacion == 1) {
                result = true;
            }
            preparedStatement.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar la persona.");
        }
        miConexion.cerrarBD();
        return result;
    }

    public boolean actualizarPosiciones(Object obj) {
        Posicion objPosiciones = (Posicion) obj;
        int result = 0;
        boolean flag = false;
        Connection conex = DbData();
        try {
            String sql = "UPDATE posiciones SET nombre=? WHERE id = ?";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setString(1, objPosiciones.getNombre());
            preparedStatement.setInt(2, objPosiciones.getId());
            result = preparedStatement.executeUpdate();

            if (result > 0) {
                flag = true;
            }
            preparedStatement.close();
            JOptionPane.showMessageDialog(null, "La actualización de el Municipio fue exitosa.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en la actualización del Municipio.");
        }
        miConexion.cerrarBD();
        return flag;
    }

    public Object listarUnPosiciones(Object obj) {
        Connection conex = DbData();
        Posicion objPosiciones = (Posicion) obj;
        try {
            String sql = "SELECT * FROM posiciones WHERE id=?;";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setInt(1, objPosiciones.getId());
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                objPosiciones.setId(resultSet.getInt("id"));
                objPosiciones.setNombre(resultSet.getString("nombre"));
            }
            preparedStatement.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la adquisición de datos");
        }
        miConexion.cerrarBD();
        return objPosiciones;
    }
    
    public List<Object> listarEquipo() {
        List<Object> rowsQuery = new ArrayList<Object>();
        Connection conex = DbData();
        Equipo objEquipo;
        try {
            String sql = "SELECT equipos.id AS id, equipos.nombre AS nombre,equipos.dt AS entrenador,equipos.municipio_id AS id_municipio FROM equipos;";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                objEquipo = new Equipo();
                objEquipo.setId(resultSet.getInt("id"));
                objEquipo.setNombre(resultSet.getString("nombre"));
                objEquipo.setDt(resultSet.getString("entrenador"));
                objEquipo.setMunicipio(resultSet.getInt("id_municipio"));

                rowsQuery.add(objEquipo);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la adquisición de datos");
        }
        miConexion.cerrarBD();
        return rowsQuery;
    }

    public Object insertarEquipo(Object obj) {
        Connection conex = DbData();
        Equipo objEquipo = (Equipo) obj;
        try {
            String sql = "INSERT INTO equipos (nombre,dt,municipio_id)VALUES(?,?,?);";
            java.sql.PreparedStatement preparedStatement
                    = (java.sql.PreparedStatement) conex.prepareStatement(sql, java.sql.PreparedStatement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, objEquipo.getNombre());
            preparedStatement.setString(2, objEquipo.getDt());
            preparedStatement.setInt(3, objEquipo.getMunicipio());

            preparedStatement.execute();
            
            preparedStatement.close();
            JOptionPane.showMessageDialog(null, "La inserción del árticulo fue exitosa.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al insertar el árticulo"+e);
        }
        miConexion.cerrarBD();
        return objEquipo;

    }

    public boolean eliminarEquipo(Object obj) {
        Equipo objEquipo = (Equipo) obj;
        boolean result = false;
        Connection conex = DbData();
        try {
            String sql = "DELETE FROM equipos WHERE id=?;";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setInt(1, objEquipo.getId());
            int resultadoEliminacion = preparedStatement.executeUpdate();
            if (resultadoEliminacion == 1) {
                result = true;
            }
            preparedStatement.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar la Equipo.");
        }
        miConexion.cerrarBD();
        return result;
    }

    public boolean actualizarEquipo(Object obj) {
        Equipo objEquipo = (Equipo) obj;
        int result = 0;
        boolean flag = false;
        Connection conex = DbData();
        try {
            String sql = "UPDATE equipos SET nombre=?,dt=?,municipio_id=? WHERE id = ?";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setString(1, objEquipo.getNombre());
            preparedStatement.setString(2, objEquipo.getDt());
            preparedStatement.setInt(3, objEquipo.getMunicipio());
            preparedStatement.setInt(4, objEquipo.getId());
            result = preparedStatement.executeUpdate();

            if (result > 0) {
                flag = true;
            }
            preparedStatement.close();
            JOptionPane.showMessageDialog(null, "La actualización de el Municipio fue exitosa.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en la actualización del Municipio.");
        }
        miConexion.cerrarBD();
        return flag;
    }

    public Object listarUnEquipo(Object obj) {
        Connection conex = DbData();
        Equipo objEquipo = (Equipo) obj;
        try {
            String sql = "SELECT * FROM equipos WHERE id=?;";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setInt(1, objEquipo.getId());
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                objEquipo.setNombre(resultSet.getString("nombre"));
                objEquipo.setDt(resultSet.getString("dt"));
                objEquipo.setMunicipio(resultSet.getInt("municipio_id"));
            }
            preparedStatement.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la adquisición de datos");
        }
        miConexion.cerrarBD();
        return objEquipo;
    }

    public List<Object> listarJugadores() {
        List<Object> rowsQuery = new ArrayList<Object>();
        Connection conex = DbData();
        Jugador objJugador;
        try {
            String sql = "SELECT jugadores.id AS id, jugadores.nombre AS nombre, jugadores.numero AS numero, jugadores.equipo_id AS equipo, jugadores.posicion_id AS posicion FROM jugadores;";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                objJugador = new Jugador();
                objJugador.setId(resultSet.getInt("id"));
                objJugador.setNombre(resultSet.getString("nombre"));
                objJugador.setNumero(resultSet.getInt("numero"));
                objJugador.setEquipoid(resultSet.getInt("equipo"));
                objJugador.setPosicionid(resultSet.getInt("posicion"));

                rowsQuery.add(objJugador);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la adquisición de datos");
        }
        miConexion.cerrarBD();
        return rowsQuery;
    }

    public Object insertarJugadores(Object obj) {
        Connection conex = DbData();
        Jugador objJugador = (Jugador) obj;
        try {
            String sql = "INSERT INTO jugadores (nombre,numero,equipo_id,posicion_id)VALUES(?,?,?,?);";
            java.sql.PreparedStatement preparedStatement
                    = (java.sql.PreparedStatement) conex.prepareStatement(sql, java.sql.PreparedStatement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, objJugador.getNombre());
            preparedStatement.setInt(2, objJugador.getNumero());
            preparedStatement.setInt(3, objJugador.getEquipoid());
            preparedStatement.setInt(4, objJugador.getPosicionid());

            preparedStatement.execute();
            
            preparedStatement.close();
            JOptionPane.showMessageDialog(null, "La inserción del árticulo fue exitosa.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al insertar el árticulo"+e);
        }
        miConexion.cerrarBD();
        return objJugador;

    }

    public boolean eliminarJugadores(Object obj) {
        Jugador objJugador = (Jugador) obj;
        boolean result = false;
        Connection conex = DbData();
        try {
            String sql = "DELETE FROM jugadores WHERE id=?;";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setInt(1, objJugador.getId());
            int resultadoEliminacion = preparedStatement.executeUpdate();
            if (resultadoEliminacion == 1) {
                result = true;
            }
            preparedStatement.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar la Equipo.");
        }
        miConexion.cerrarBD();
        return result;
    }

    public boolean actualizarJugadores(Object obj) {
        Jugador objJugador = (Jugador) obj;
        int result = 0;
        boolean flag = false;
        Connection conex = DbData();
        try {
            String sql = "UPDATE jugadores SET nombre=?,numero=?,equipo_id=?,posicion_id=? WHERE id = ?";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setString(1, objJugador.getNombre());
            preparedStatement.setInt(2, objJugador.getNumero());
            preparedStatement.setInt(3, objJugador.getEquipoid());
            preparedStatement.setInt(4, objJugador.getPosicionid());
            preparedStatement.setInt(5, objJugador.getId());
            result = preparedStatement.executeUpdate();

            if (result > 0) {
                flag = true;
            }
            preparedStatement.close();
            JOptionPane.showMessageDialog(null, "La actualización de el Municipio fue exitosa.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en la actualización del Municipio.");
        }
        miConexion.cerrarBD();
        return flag;
    }

    public Object listarUnJugadores(Object obj) {
        Connection conex = DbData();
        Jugador objJugador = (Jugador) obj;
        try {
            String sql = "SELECT * FROM jugadores WHERE id=?;";
            java.sql.PreparedStatement preparedStatement = (java.sql.PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setInt(1, objJugador.getId());
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                objJugador.setNombre(resultSet.getString("nombre"));
                objJugador.setNumero(resultSet.getInt("numero"));
                objJugador.setEquipoid(resultSet.getInt("equipo_id"));
                objJugador.setEquipoid(resultSet.getInt("Posicion_id"));
            }
            preparedStatement.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la adquisición de datos");
        }
        miConexion.cerrarBD();
        return objJugador;
    }
}
