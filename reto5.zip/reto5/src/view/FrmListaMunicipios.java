package view;

import com.mysql.jdbc.ResultSet;
import controller.TorneoController;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import models.Municipio;

public class FrmListaMunicipios extends javax.swing.JFrame {

    TorneoController objTorneoController = new TorneoController();
    Municipio objMunicipio = new Municipio();
    int idMunicipio = 0;
    DefaultTableModel modeloTabla;

    public FrmListaMunicipios() {
        initComponents();
        this.refrescarTabla();
    }

    private void refrescarTabla() {
        DefaultTableModel modeloTabla = (DefaultTableModel) tbLMunicipios.getModel();
        modeloTabla.setRowCount(0);

        String filaDeTabla[] = new String[2];

        for (Object obj : objTorneoController.listarMunicipio()) {
            Municipio objPer = (Municipio) obj;
            filaDeTabla[0] = Integer.toString(objPer.getId());
            filaDeTabla[1] = objPer.getNombre();

            modeloTabla.addRow(filaDeTabla);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbLMunicipios = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtNombreMunicipio = new javax.swing.JTextField();
        btnInsertar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuMunicipio = new javax.swing.JMenu();
        subMenuListaMunicipios = new javax.swing.JMenuItem();
        menuEquipo = new javax.swing.JMenu();
        subMenuListaEquipos = new javax.swing.JMenuItem();
        menuJugador = new javax.swing.JMenu();
        subMenuListaJugadores = new javax.swing.JMenuItem();
        menuPosicion = new javax.swing.JMenu();
        subMenuListaPosiciones = new javax.swing.JMenuItem();
        menuInicio = new javax.swing.JMenu();
        subMenuInicio = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 0), null));

        tbLMunicipios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "#", "municipio"
            }
        ));
        tbLMunicipios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbLMunicipiosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbLMunicipios);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("LISTA DE MUNICIPIOS");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 637, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(8, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 408, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 0), null));

        jLabel2.setFont(new java.awt.Font("Segoe UI Historic", 3, 24)); // NOI18N
        jLabel2.setText("Datos:");

        jLabel3.setText("Nombre del Municipio:");

        btnInsertar.setText("INSERTAR");
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnActualizar.setText("ACTUALIZAR");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnLimpiar.setText("LIMPIAR");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnLimpiar, javax.swing.GroupLayout.DEFAULT_SIZE, 296, Short.MAX_VALUE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnActualizar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnInsertar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtNombreMunicipio, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 296, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(27, 27, 27)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtNombreMunicipio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnInsertar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnActualizar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnEliminar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnLimpiar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        menuMunicipio.setText("Municipios");

        subMenuListaMunicipios.setText("Lista de Municipios");
        subMenuListaMunicipios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subMenuListaMunicipiosActionPerformed(evt);
            }
        });
        menuMunicipio.add(subMenuListaMunicipios);

        jMenuBar1.add(menuMunicipio);

        menuEquipo.setText("Equipos");

        subMenuListaEquipos.setText("Lista de Equipos");
        subMenuListaEquipos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subMenuListaEquiposActionPerformed(evt);
            }
        });
        menuEquipo.add(subMenuListaEquipos);

        jMenuBar1.add(menuEquipo);

        menuJugador.setText("Jugadores");

        subMenuListaJugadores.setText("Lista de Jugadores");
        subMenuListaJugadores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subMenuListaJugadoresActionPerformed(evt);
            }
        });
        menuJugador.add(subMenuListaJugadores);

        jMenuBar1.add(menuJugador);

        menuPosicion.setText("Posición");

        subMenuListaPosiciones.setText("Lista de Posiciones");
        subMenuListaPosiciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subMenuListaPosicionesActionPerformed(evt);
            }
        });
        menuPosicion.add(subMenuListaPosiciones);

        jMenuBar1.add(menuPosicion);

        menuInicio.setText("INICIO");

        subMenuInicio.setText("Inicio");
        subMenuInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subMenuInicioActionPerformed(evt);
            }
        });
        menuInicio.add(subMenuInicio);

        jMenuBar1.add(menuInicio);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 483, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void subMenuListaMunicipiosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subMenuListaMunicipiosActionPerformed
        FrmListaMunicipios objFrmListaMunicipios = new FrmListaMunicipios();
        objFrmListaMunicipios.setLocationRelativeTo(null);
        objFrmListaMunicipios.setVisible(true);
    }//GEN-LAST:event_subMenuListaMunicipiosActionPerformed

    private void subMenuListaEquiposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subMenuListaEquiposActionPerformed
        FrmListaEquipos objFrmListaEquipo = new FrmListaEquipos();
        objFrmListaEquipo.setLocationRelativeTo(null);
        objFrmListaEquipo.setVisible(true);
    }//GEN-LAST:event_subMenuListaEquiposActionPerformed

    private void subMenuListaJugadoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subMenuListaJugadoresActionPerformed
        FrmListaJugadores objFrmListaJugadores = new FrmListaJugadores();
        objFrmListaJugadores.setLocationRelativeTo(null);
        objFrmListaJugadores.setVisible(true);
    }//GEN-LAST:event_subMenuListaJugadoresActionPerformed

    private void subMenuListaPosicionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subMenuListaPosicionesActionPerformed
        FrmListaPosiciones objFrmListaPosiciones = new FrmListaPosiciones();
        objFrmListaPosiciones.setLocationRelativeTo(null);
        objFrmListaPosiciones.setVisible(true);
    }//GEN-LAST:event_subMenuListaPosicionesActionPerformed

    private void subMenuInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subMenuInicioActionPerformed
        FrmFormulario objFrmCartera = new FrmFormulario();
        objFrmCartera.setLocationRelativeTo(null);
        objFrmCartera.setVisible(true);
    }//GEN-LAST:event_subMenuInicioActionPerformed

    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarActionPerformed
        String nombre = txtNombreMunicipio.getText();
        objMunicipio.setNombre(nombre);
        objTorneoController.insertarMunicipio(objMunicipio);

        this.limpiar();
        this.refrescarTabla();
    }//GEN-LAST:event_btnInsertarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        if (idMunicipio > 0) {

            objMunicipio.setId(idMunicipio);
            objMunicipio.setNombre(this.txtNombreMunicipio.getText());

            objTorneoController.actualizarMunicipio(objMunicipio);

            this.refrescarTabla();
        } else {
            JOptionPane.showMessageDialog(this, "No se seleccionó Municipio.");
        }
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        if (idMunicipio > 0) {
            int fila = this.tbLMunicipios.getSelectedRow();
            int opcion = JOptionPane.showConfirmDialog(null, "¿Esta seguro que quiere eliminar el municipio ?", "Eliminar Municipio", JOptionPane.YES_NO_OPTION);

            if (opcion == JOptionPane.YES_OPTION) {
                objMunicipio.setId(idMunicipio);
                objTorneoController.eliminarMunicipio(objMunicipio);
            } else {
                JOptionPane.showMessageDialog(this, "Tuviste misericordia. Gracias.");
            }

            this.refrescarTabla();

        } else {
            JOptionPane.showMessageDialog(this, "No se seleccionó Municipio.");
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        this.limpiar();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void tbLMunicipiosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbLMunicipiosMouseClicked
        int fila = this.tbLMunicipios.getSelectedRow();
        idMunicipio = Integer.parseInt(this.tbLMunicipios.getValueAt(fila, 0).toString());

        objMunicipio.setId(idMunicipio);
        objMunicipio = (Municipio) objTorneoController.listarUnMunicipio(objMunicipio);

        txtNombreMunicipio.setText(objMunicipio.getNombre());


    }//GEN-LAST:event_tbLMunicipiosMouseClicked

    private void limpiar() {
        idMunicipio = 0;
        txtNombreMunicipio.setText("");
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmListaMunicipios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenu menuEquipo;
    private javax.swing.JMenu menuInicio;
    private javax.swing.JMenu menuJugador;
    private javax.swing.JMenu menuMunicipio;
    private javax.swing.JMenu menuPosicion;
    private javax.swing.JMenuItem subMenuInicio;
    private javax.swing.JMenuItem subMenuListaEquipos;
    private javax.swing.JMenuItem subMenuListaJugadores;
    private javax.swing.JMenuItem subMenuListaMunicipios;
    private javax.swing.JMenuItem subMenuListaPosiciones;
    private javax.swing.JTable tbLMunicipios;
    private javax.swing.JTextField txtNombreMunicipio;
    // End of variables declaration//GEN-END:variables
}
